# therapeutic-bot
 “A Flask-based therapeutic chatbot using a transformer model.”
